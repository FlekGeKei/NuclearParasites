package pl.asie.computronics.api.chat;

public class ChatAPI {

	public static IChatListenerRegistry registry;
}
