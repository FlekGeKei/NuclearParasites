package pl.asie.computronics.api.audio;

import net.minecraft.util.EnumFacing;

public interface IAudioConnection {

	boolean connectsAudio(EnumFacing side);
}
