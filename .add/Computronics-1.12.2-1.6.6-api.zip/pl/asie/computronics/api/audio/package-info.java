/**
 * @author asie
 */

@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
@API(apiVersion = "1.0", owner = "asielib", provides = "computronicsAPI|audio")
package pl.asie.computronics.api.audio;

import mcp.MethodsReturnNonnullByDefault;
import net.minecraftforge.fml.common.API;

import javax.annotation.ParametersAreNonnullByDefault;
