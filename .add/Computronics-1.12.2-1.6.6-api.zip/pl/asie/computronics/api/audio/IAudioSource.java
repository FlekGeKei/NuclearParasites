package pl.asie.computronics.api.audio;

public interface IAudioSource extends IAudioConnection {

	int getSourceId();
}
