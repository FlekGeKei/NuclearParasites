/**
 * @author Vexatos
 */

@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
@API(apiVersion = "1.0", owner = "asielib", provides = "computronicsAPI|tape")
package pl.asie.computronics.api.tape;

import mcp.MethodsReturnNonnullByDefault;
import net.minecraftforge.fml.common.API;

import javax.annotation.ParametersAreNonnullByDefault;
