/**
 * @author Vexatos
 */

@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
@API(apiVersion = "1.1", owner = "asielib", provides = "computronicsAPI|multiperipheral")
package pl.asie.computronics.api.multiperipheral;

import mcp.MethodsReturnNonnullByDefault;
import net.minecraftforge.fml.common.API;

import javax.annotation.ParametersAreNonnullByDefault;
