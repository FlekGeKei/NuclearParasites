/**
 * @author Vexatos
 */

@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
@API(apiVersion = "1.1", owner = "asielib", provides = "asielibAPI|tool")
package pl.asie.lib.api.tool;

import mcp.MethodsReturnNonnullByDefault;
import net.minecraftforge.fml.common.API;

import javax.annotation.ParametersAreNonnullByDefault;
