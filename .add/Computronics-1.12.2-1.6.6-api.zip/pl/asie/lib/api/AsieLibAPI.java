package pl.asie.lib.api;

public class AsieLibAPI {

	public static AsieLibAPI instance;

}
