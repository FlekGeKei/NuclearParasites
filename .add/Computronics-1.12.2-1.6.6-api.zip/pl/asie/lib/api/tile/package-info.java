/**
 * @author Vexatos
 */

@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
@API(apiVersion = "1.0", owner = "asielib", provides = "asielibAPI|tile")
package pl.asie.lib.api.tile;

import mcp.MethodsReturnNonnullByDefault;
import net.minecraftforge.fml.common.API;

import javax.annotation.ParametersAreNonnullByDefault;
